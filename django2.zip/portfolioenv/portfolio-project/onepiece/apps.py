from django.apps import AppConfig


class OnepieceConfig(AppConfig):
    name = 'onepiece'
